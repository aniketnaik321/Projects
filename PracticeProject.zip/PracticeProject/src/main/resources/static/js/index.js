$(function(){

var masterTable= $("#tblEmployee").DataTable({
		        dom:"tp",
		       "scrollX": true ,
		        destroy:true,
		        "processing": true,
		        "serverSide": true,
		        "ajax" : {
					"url" : "./employees",
					"type" : "GET",
					"dataSrc" : ""					
				},
				 "scrollX": true ,	
				 pageLenth:"50",
				  columns:[		        	
		        	{data:'empId',title:'Employee ID'},
		        	{data:'empName',title:'Employee Name'},
		        	{data:'department',title:'Department'},
		        	{data:'designation',title:'Designation'},
		        	{data:'skills',title:'Skills'}		        		        	
		        ]
		     
       	 });

});