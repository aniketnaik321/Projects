package com.gfxtech.controller;

import java.util.Enumeration;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.gfxtech.dto.DtoEmployee;
import com.gfxtech.service.EmployeeService;


@Controller
public class EmployeeController {
	
	@Autowired
	private EmployeeService _employeeService; 
	
	
	@GetMapping("/")
	public ModelAndView ReportConfiguration() {		
		ModelAndView _result=new ModelAndView();	
		
		_result.setViewName("Index");
		return _result;					
	}
	
	@RequestMapping(value="/employees",method = RequestMethod.GET,produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody DtoEmployee[] getEmployees(HttpServletRequest request) {		
		String uniqueId;			 				
		  String draw;
		  Integer start=0;
		  Integer length=50;	
		Enumeration<String> parameterNames = request.getParameterNames();	    	
  	if(parameterNames.hasMoreElements()) {	     
  		start = Integer.parseInt(request.getParameter("start"));
   length= (Integer.parseInt(request.getParameter("length")));
   uniqueId= (request.getParameter("_"));
   draw=request.getParameter("DRAW");
		
	}
		return _employeeService.getEmployeeList(start, length);	 		
		
	}
	
	

}
