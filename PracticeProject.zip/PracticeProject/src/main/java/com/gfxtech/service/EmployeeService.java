package com.gfxtech.service;

import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import org.springframework.stereotype.Service;

import com.gfxtech.dto.DtoEmployee;
import com.gfxtech.repository.EmployeeRepository;

@Service
public class EmployeeService {	
	@Autowired
	private ModelMapper _mapper;
	@Autowired
	private EmployeeRepository _employeeRepository;
	
	public DtoEmployee[] getEmployeeList(int pageNo,int pageLength){
		Pageable pageable=PageRequest.of(pageNo, pageLength);		
		//Usage of ModelMapper to convert entity class to Dto class
		return _mapper.map(_employeeRepository.findAll(pageable).getContent(),DtoEmployee[].class);		
	}
	
	
}
