package com.gfxtech.dto;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.Date;
import lombok.Data;

public class DtoEmployee implements Serializable {	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private BigInteger empId;
	private String empName;
	private String department;
	private Date dob;
	private String designation;
	private String skills;
	public BigInteger getEmpId() {
		return empId;
	}
	public void setEmpId(BigInteger empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getSkills() {
		return skills;
	}
	public void setSkills(String skills) {
		this.skills = skills;
	}
	
	
	
	
}
