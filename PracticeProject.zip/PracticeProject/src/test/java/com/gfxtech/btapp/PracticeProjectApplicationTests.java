package com.gfxtech.btapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PracticeProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
